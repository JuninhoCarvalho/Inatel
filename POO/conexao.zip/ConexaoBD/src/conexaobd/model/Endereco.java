/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexaobd.model;

/**
 *
 * @author PICHAU
 */
public class Endereco {
    public int id;
    public String rua;
    public String bairro;
    public String numero;
}
